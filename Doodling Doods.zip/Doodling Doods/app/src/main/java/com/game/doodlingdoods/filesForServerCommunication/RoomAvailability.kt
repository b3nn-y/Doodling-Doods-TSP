package com.game.doodlingdoods.filesForServerCommunication

data class RoomAvailability(
    var roomAvailable: Boolean,
    var roomPass: String
)
