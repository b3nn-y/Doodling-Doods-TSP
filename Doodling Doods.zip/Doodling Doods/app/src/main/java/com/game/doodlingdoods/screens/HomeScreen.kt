package com.game.doodlingdoods.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.game.doodlingdoods.R


//This is the home screen, where the user either chooses online or local game mode.

@Composable
fun HomeScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {

    Box(modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center){

        Image(painter = painterResource(id = R.drawable.background),
            contentDescription = "bg image",
            contentScale = ContentScale.FillBounds,
            modifier = modifier.fillMaxSize())

        Column(
            modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            NavBar()
            Titlebar()

            PlayOption(
                PlayButtonClick = {
                    navController.navigate("AccountSetup")
                }
            )
        }
    }
}

// navbar contains user profile and their stats
@Composable
fun NavBar(modifier: Modifier = Modifier) {
    Box(
        modifier.fillMaxWidth()

    ) {
        Row(
            modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {}
    }
}


//title bar for game title it appears on middle of the screen
@Composable
fun Titlebar(modifier: Modifier = Modifier) {
    Box(
        modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {

        Image(painter = painterResource(id = R.drawable.app_logo), contentDescription = "logo")

    }


}
//play button

@Composable
fun PlayOption(
    modifier: Modifier = Modifier,
    PlayButtonClick: () -> Unit
) {

//    Card(
//        modifier
//            .fillMaxWidth()
//            .padding(48.dp)
//            .clickable {
//                PlayButtonClick()
//            },
//
//
//        ) {
//        Text(
//            text = "Play",
//            fontSize = 30.sp,
//            fontWeight = FontWeight.Bold,
//            modifier = Modifier
//                .align(Alignment.CenterHorizontally)
//                .padding(8.dp)
//        )
//    }

    var scale by remember {
        mutableStateOf(1f)
    }

    val animation = rememberInfiniteTransition()

    scale = animation.animateFloat(
        label = "ScaleAnimation",
        initialValue = 1f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 3000
                0.85f at 1500
                1f at 3000
            },
            repeatMode = RepeatMode.Reverse
        )
    ).value

    Image(
        painter = painterResource(id = R.drawable.play_button),
        contentDescription = "Play!",
        modifier = Modifier
            .size(200.dp * scale)
            .clickable {
                PlayButtonClick()
            })

}
@Preview
@Composable
fun PreviewNavbar() {
//    NavBar(modifier = Modifier)
//    Titlebar()
//    PlayOption()
//    HomeScreen()
}
