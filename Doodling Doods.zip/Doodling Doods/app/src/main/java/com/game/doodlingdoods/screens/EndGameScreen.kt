package com.game.doodlingdoods.screens

//This screen is shown as soon as a game is over and shows the top scores of the current players and their stats.

class EndGameScreen {
}