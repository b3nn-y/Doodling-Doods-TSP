package com.game.doodlingdoods.screens
//This screen shows the global leaderboard and the player's stats
class LeaderBoardScreen {
}