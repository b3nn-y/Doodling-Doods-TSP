package com.game.doodlingdoods.users

data class AuthenticationDataClass(val isAuthorized:Boolean)
