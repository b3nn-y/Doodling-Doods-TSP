package com.game.doodlingdoods

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

//This file is used to integrate Hilt ViewModel

@HiltAndroidApp
class MyApp : Application()