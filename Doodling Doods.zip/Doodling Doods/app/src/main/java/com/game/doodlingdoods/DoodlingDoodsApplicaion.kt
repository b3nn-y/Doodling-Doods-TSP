package com.game.doodlingdoods

import android.app.Application
import android.content.Context
//import com.game.doodlingdoods.internetConnection.NetworkMonitor
//import com.game.doodlingdoods.internetConnection.NetworkMonitorImpl

//class DoodlingDoodsApplicaion: Application(){
//
//    companion object {
//        lateinit var appContext: Context
//    }
//    override fun onCreate() {
//        super.onCreate()
//        appContext = this
//        NetworkMonitorImpl.registerNetworkChangeCallback()
//    }
//}
//
//fun globalContext(): Context{
//    return DoodlingDoodsApplicaion.appContext;
//}