package com.game.doodlingdoods.GameApi

data class RoomDetailsDataClass(

    val id: Int,
    val room_id: String,
    val created_by: String,
    val password: String,

)