package com.game.doodlingdoods.filesForServerCommunication

data class QueryRoom(
    var room_id:String
)
