package com.game.doodlingdoods.viewmodels

import android.util.Log
import androidx.lifecycle.ViewModel
import com.game.doodlingdoods.GameApi.KtorServerApi

class RoomsViewModel:ViewModel() {


}